# Expose main function when the package is imported as a module
from .__main__ import main
